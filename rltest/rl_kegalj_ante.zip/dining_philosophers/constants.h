
#ifndef BLA
#define BLA

#define N 5


#endif
